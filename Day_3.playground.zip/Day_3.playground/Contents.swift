//: Playground - noun: a place where people can play

import UIKit

func display()
{
    print("loveleen")
}

display()

func display(name:String)
{
    print("welcome,\(name)")
}

display(name:"loveleen")

func display(n: Int)
{
    for i in 1...n
    {
    print(i)
    }
}

display(n:5)
func display(_ n: Int)
{
    for i in 1...n
    {
        print(i)
    }
}

display(5)

func add(_ a: Int, b: Int)
{
    print("Sum : \(a+b)")
}

add(10, b:20)

func sum(of a: Int, and b: Int)
{
    print("Add : \(a+b)")
}

sum(of:10, and:20)

func display(number n: Int)
{
    for i in 1...n
    {
        print(i)
    }
}
display(number:5)

func greet() ->String
{
    return "welcome to lambton"
}
var s = greet()
print(s)


func add(_ a: Int,_  b: Int)->Int
    {
        return (a+b)
}

func add(_ a: Float,_ b: Float)-> Float
{
    return (a+b)
}

func add(_ a: String, _ b: String)-> String
{
    return a+b
}

print(add(1,2))
print(add(1,1.2))
print(add("hello"," world"))
//return tupples
func swip(a: String,b: String) -> (String,String)
{
    return(b,a)
}

let x = swip(a: "loveleen",b: "kaur")
print(x.0,x.1)

func swip(a: Int,b: Int) -> (a:Int, b:Int)
{
    return(b,a)
}
let z = swip(a: 100,b: 200)
print(z.a,z.b)


//passing array
func addValues(arr:[Int]) -> Int
{
    var add = 0
    for i in arr
    {
        add = add + i
    }
    return add
}

print (addValues(arr: [2,3,2]))
var na = [100,200,50,140]
print(addValues(arr: na))

// passing array and return type

func findMinMax(arr:[Int]) -> (min:Int,max:Int)
{
    return (arr.min() ?? 0,arr.max() ?? 0)
}

var minmax = findMinMax(arr: [200,30,60,800,100])
print(minmax.min, minmax.max)

//default parameter

func si(amount: Double, noOfyears: Int, rateofinterest: Float = 0.5)
    -> Double
{
    return(amount * Double(noOfyears) * Double(rateofinterest))
}
print(si(amount: 1000, noOfyears: 5))
print(si(amount: 1000, noOfyears: 5, rateofinterest: 1.25))

//default parameter inbetween when label

func sii(amount: Double, noOfyears: Int = 5, rateofinterest: Float )
    -> Double
{
    return(amount * Double(noOfyears) * Double(rateofinterest))
}
print(sii(amount: 2000, rateofinterest: 1.5))

//default parameter without label

func siii(_ amount: Double,_ noOfyears: Int = 5,_ rateofinterest: Float )
    -> Double
{
    return(amount * Double(noOfyears) * Double(rateofinterest))
}
print(siii( 2000,0, 1.5))
print(siii(1000,5,1.25))

//inout example
func swapTwoInts(_ a: inout Int, _ b: inout Int) {
    let temporaryA = a
    a = b
    b = temporaryA
}
var x1 = 100
var x2 = 200

print(x1,x2)
swapTwoInts(&x1,&x2)
print(x1,x2)

//inbuilt function provide by swift libraray
swap(&x1,&x2)
func printValues(a : Int)
{
    for i in a
    {
        print(i)
        
    }
}
printValues(a: [5,4,3,2,1])
print("--------")
func printValues(b : Int, _ a : Int...)
{
    for i in a
    {
        print(i)

    }
}
printValues(a: 1,2,50,100,30,60)
