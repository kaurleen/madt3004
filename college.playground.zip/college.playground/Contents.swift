//: Playground - noun: a place where people can play

import UIKit

class College
{
    var cid: Int?
    var cnm: String!
    var cadd: String!
    var cphn: String!

init()
{
    self.cid = 111
    self.cnm = ""
    self.cadd = ""
    self.cphn = ""
}


    init(cid: Int, cnm: String, cadd: String, cphn: String)
{
    self.cid = cid
    self.cnm = cnm
    self.cadd = cadd
    self.cphn = cphn
}


func display()

{
   
    print("cid : \(self.cid!)\ncnm : self.cnm!)\nadd : self.cadd!)\nphn : self.cphn!)")
}

deinit
{
    print("college class - out of scope/memory")

}
}
