//: Playground - noun: a place where people can play

import UIKit


var letters = Set<Character>()
letters.insert("A")
letters.insert("B")
print("count \(letters.count)")
letters.insert("A")
print("count \(letters.count)")

var str = "hello world 😀"

var a = "\u{24}"
var b = "\u{1F496}"
var c = "\u{65}"
print(a,b,c)

let longString = """
abfjskskls
hnkhkjh
ncbueirfnjr
"""

print(longString)

print("\"hello\",loveleen")

var s = String()

s = "welcome to lambton"

for c in s
{
    print(c)
}
