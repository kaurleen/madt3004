//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var a = ["name":"loveleen","city":"toronto"]

print("keys/values")
for (k,v) in a
{
    print("\(k)-->\(v)")
}

a["job"] = "software developer"

print("only keys")
for k in a.keys
{
    print("\(k)")
}
print("only values")
for v in a.values{
    print("\(v)")
}
if let ov = a.updateValue("london", forKey: "city")
{
  print("the old value for city was \(ov).")
}
print("extract keys and store in array")
let keys = [String](a.keys)

for i in keys
{
print(i)
}
